<h2>Você recebeu um novo contato do site J6</h2>

<p>
    <strong>Nome: </strong> {{ $data["nome"] }}
</p>
<p>
    <strong>E-mail: </strong> {{ $data["email"] }}
</p>
<p>
    <strong>Telefone: </strong> {{ $data["telefone"] }}
</p>
<p>
    <strong>Assunto: </strong> {{ $data["assunto"] }}
</p>
<p>
    <strong>Mensagem: </strong> {{ $data["mensagem"] }}
</p>