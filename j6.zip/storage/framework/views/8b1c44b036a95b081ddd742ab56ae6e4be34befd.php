
<?php $__env->startSection('title','Veja um pouco do nosso trabalho - J6 Soluções Digitais'); ?>
<?php $__env->startSection('description','Sites incríveis, artes digitais, Posts para redes sociais, Marketing Digital e muito mais confira.'); ?>
<?php $__env->startSection('content'); ?>
<section class="page-header">

    <div class="container text-center">
        <h2>Portfólio</h2>
        <ul class="list-unstyled thm-breadcrumb">
            <li><a href="<?php echo e(config("app.url")); ?>">Home</a></li>
            <li><span>Portfólio</span></li>
        </ul><!-- /.thm-breadcrumb -->
    </div><!-- /.container text-center -->
</section><!-- /.page-header -->


<section class="portfolio-grid" style="margin: -150px 0 0 0;">
    <div class="container">
        <div class="block-title text-center">
            <p class="color-2"><span>Portfolio</span></p>
            <h3>Um pedacinho da galáxia <br> <span>& Alguns jobs nossos</span></h3>
        </div><!-- /.block-title text-center -->
        <ul class="portfolio-filter list-unstyled post-filter ">
            <li data-filter=".filter-item" class="active"><span>Todos</span></li>
            <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li data-filter=".<?php echo e($itemMenu["tag"]); ?>"><span><?php echo e($itemMenu["titulo"]); ?></span></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul><!-- /.portfolio-filter list-unstyled -->
        <div class="row high-gutters masonary-layout filter-layout">
            <?php $__currentLoopData = $portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemPortfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-12 filter-item masonary-item  <?php echo e($itemPortfolio["menu"]["tag"]); ?>">
                    <div class="portfolio-one__single">
                        <div class="portfolio-one__image">
                            <img src="<?php echo e(asset('j6/thumb/'.$itemPortfolio["img"])); ?>">
                            <a href="<?php echo e(asset('j6/'.$itemPortfolio["img"])); ?>" data-lightbox="<?php echo e($itemPortfolio["menu"]["tag"]); ?>">
                                <i class="fal fa-plus"></i>
                            </a>
                        </div>
                        <div class="portfolio-one__content">
                            <h3><a href="javascript:void(0)"><?php echo e($itemPortfolio["titulo"]); ?></a></h3>
                            <p><?php echo e($itemPortfolio["menu"]["titulo"]); ?></p>
                        </div>
                    </div>
                </div><!-- final sessao -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.portfolio-grid -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.inovex.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\j6\resources\views/templates/inovex/portfolio.blade.php ENDPATH**/ ?>