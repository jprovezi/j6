
<?php $__env->startSection('title', $seo['titulo']); ?>
<?php $__env->startSection('description', $seo['descricao']); ?>
<?php $__env->startSection('menuSolucoes'); ?>
    <?php $__currentLoopData = $solucoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e($item["url-single"]); ?>"><?php echo e($item["titulo"]); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="page-header">
        <div class="particles-snow" id="header-snow"></div><!-- /#header-snow.particles-snow -->
        <div class="container text-center">
            <h2><?php echo e($info['titulo']); ?></h2>
            <ul class="list-unstyled thm-breadcrumb">
                <li><a href="<?php echo e(config('app.url')); ?>">Home</a></li>
                <li><a href="<?php echo e(config('app.url')); ?>/solucoes">Soluções</a></li>
                <li><span><?php echo e($info['titulo']); ?></span></li>
            </ul><!-- /.thm-breadcrumb -->
        </div><!-- /.container text-center -->
    </section><!-- /.page-header -->

    <section class="service-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="sidebar sidebar__left">
                        <div class="sidebar__single sidebar__category">
                            <ul class="list-unstyled sidebar__category-list">
                                <?php $__currentLoopData = $solucoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php echo e($item['active']); ?>">
                                        <a href="<?php echo e($item['url-single']); ?>"><?php echo e($item['titulo']); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div><!-- /.sidebar__single -->
                        <div class="sidebar__single sidebar__contact">
                            <h3 class="sidebar__title">Contato</h3>
                            <ul class="list-unstyled sidebar__contact-list">
                                <li>
                                    <i class="fa fa-map-marker-alt"></i>
                                    Balneário Piçarras, SC
                                </li>
                                <li>
                                    <i class="fa fa-envelope"></i>
                                    <a href="mailto:diretoria@j6.net.br">diretoria@j6.net.br</a>
                                </li>
                                <li>
                                    <i class="fa fa-phone"></i>
                                    <a href="tel:+5547997758281">+55 (47)997758281</a>
                                </li>
                            </ul>
                        </div><!-- /.sidebar__single -->
                        <div class="sidebar__single sidebar__brouchers">
                            <h3 class="sidebar__title">Material Extra</h3>
                            <ul class="list-unstyled sidebar__category-list">
                                <li>
                                    <a href="<?php echo e(asset('templates/inovex/pdf/apresentacao.pdf')); ?>" target="_blank">Apresentação em PDF <i
                                            class="far fa-file-pdf"></i></a>
                                </li>
                            </ul><!-- /.list-unstyled sidebar__category-list -->
                        </div><!-- /.sidebar__single -->
                    </div><!-- /.sidebar -->
                </div><!-- /.col-lg-4 -->
                <div class="col-lg-8">
                    <div class="service-details__main">
                        <div class="service-details__image">
                            <img src=<?php echo e(asset('j6/' . $info['capa'])); ?> />
                        </div><!-- /.service-details__image -->
                        <div class="service-details__content">
                            <h3><?php echo e($info['titulo']); ?></h3>
                            <p><?php echo $info["descricao"]; ?></p>
                            <ul class="service-details__list list-unstyled">
                                <?php $__currentLoopData = $info["destaques"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destaques): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><i class="fa fa-check-circle"></i><?php echo e($destaques); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul><!-- /.service-details__list list-unstyled -->
                            <br>
                            <div class="row">
                                <?php $__currentLoopData = $info["img-exemplo"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    <a href="<?php echo e(asset('j6/'.$img)); ?>" data-lightbox="image">
                                        <img src="<?php echo e(asset('j6/'.$img)); ?>" class="img-responsive" style="margin-top: 0px;">
                                    </a>
                                </div><!-- /.col-lg-6 -->                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div><!-- /.row -->
                            <br>
                            <p class="destaque">Todas as nossas soluções são de alta qualidade, faça como muitas empresas e profissionalize o
                                digital do seu negócio.</p>
                        </div><!-- /.service-details__content -->
                    </div><!-- /.service-details__main -->
                </div><!-- /.col-lg-8 -->

            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.blog-standard -->

    <?php if(!is_null($planos)): ?>
    <section class="pricing-one" style="margin: -200px 0 0 0;">
        <div class="container">
            <div class="block-title text-center">
                <p class="color-2"><span>Nossos Planos</span></p>
                <h3>Confira nossos planos</span></h3>
            </div><!-- /.block-title text-center -->
    
            <div class="row high-gutters">
                <?php $__currentLoopData = $planos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 wow fadeInLeft" data-wow-duration="1500ms">
                    <div class="pricing-one__single">
                        <div class="">
                            <img src="<?php echo e(asset("j6/".$item["img"])); ?>">
                        </div><!-- /.pricing-one__icon -->
                        <h3><?php echo e($item["titulo"]); ?></h3>
                        <ul class="pricing-one__list list-unstyled">
                            <?php $__currentLoopData = $item["itens"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($valor); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li class="disabled">* Valores para planos de 12 meses</li>
                        </ul><!-- /.pricing-one__list list-unstyled -->
                        <p><?php echo e($item["valor"]); ?></p>
                        <a href="<?php echo e($item["url"]); ?>" class="thm-btn pricing-one__btn" style="width: 70%;">
                            Fale Conosco
                        </a>
                    </div><!-- /.pricing-one__single -->
                </div><!-- /.col-lg-4 -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><!-- /.row -->
        </div><!-- /.container -->
    </section><!-- /.pricing-one -->    
    <?php endif; ?>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.inovex.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\j6\resources\views/templates/inovex/solucoes-single.blade.php ENDPATH**/ ?>