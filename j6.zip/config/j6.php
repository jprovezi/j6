<?php

return [

    'cliente' => env('J6_CLIENTE', 'J6 Soluções Digitais'), 

];
